package domain;

public enum TagStatus {
    SELECTED, NOTSELECTED, MAYBE;
}
